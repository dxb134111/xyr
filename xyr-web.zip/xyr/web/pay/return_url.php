<?php
$mod='blank';
include("../api.inc.php");

/* * 
 * 功能：支付宝页面跳转同步通知页面
 * 版本：3.3
 * 日期：2012-07-23
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。

 *************************页面功能说明*************************
 * 该页面可在本机电脑测试
 * 可放入HTML等美化页面的代码、商户业务逻辑程序代码
 * 该页面可以使用PHP开发工具调试，也可以使用写文本函数logResult，该函数已被默认关闭，见alipay_notify_class.php中的函数verifyReturn
 */

require_once("alipay.config.php");
require_once("lib/alipay_notify.class.php");
?>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
        
        <div class="main-content">
            
            <!-- Xenon Counter Widget -->
            <div class="row">
                    
                <div class="col-sm-12">
                                                    
<?php
//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyReturn();
if($verify_result) {//验证成功
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //请在这里加上商户的业务逻辑程序代码
    
    //——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
    //获取支付宝的通知返回参数，可参考技术文档中页面跳转同步通知参数列表

    //商户订单号

    $out_trade_no = $_GET['out_trade_no'];

    //支付宝交易号

    $trade_no = $_GET['trade_no'];

    //交易状态
    $trade_status = $_GET['trade_status'];


    if($_GET['trade_status'] == 'TRADE_FINISHED' || $_GET['trade_status'] == 'TRADE_SUCCESS') {
        //判断该笔订单是否在商户网站中已经做过处理
            //如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
            //如果有做过处理，不执行商户的业务程序
    }
    else {
      echo "trade_status=".$_GET['trade_status'];
    }


    //获取单号信息：
    $buyerid = $_GET['buyer_id'];

    //获取用户信息：
    $u = $_GET['body'];
    $res=$DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' limit 1");
    $p = $res['pass'];
    $u_ll = $res['maxll'];

    //获取代理信息：
    $dlid = $res['dlid'];
    if($dlid){
        
    }
    else{
        $dlid = 0;
    }
    $dl_res=$DB->get_row("SELECT * FROM `auth_daili` where `id`='$u' limit 1");
    $dl_u = $dl_res['user'];
    $dl_p = $dl_res['pass'];
    $dl_rmb=$dl_res['rmb'];

    //判断是用户，进行充值
    $user = $DB->get_row("SELECT * FROM `openvpn` where `iuser`='$u' and `pass`='$p' limit 1");
    if($user){

            //获取卡密的分类：
            $kmtype_name =$_GET['subject'];
            $kmtype=$DB->get_row("SELECT * FROM `kmtype` WHERE `name` LIKE '$kmtype_name'");
                //echo "<script language='javascript'>alert('商品名称".$kmtype_name."');</script>";
            $kmtype_id =$kmtype['id'];
            $km_rmb = $kmtype['km_rmb'];

            //获取卡密信息：
            $kmsql=$DB->get_row("SELECT * FROM `auth_kms` WHERE `daili` = $dlid AND `isuse` = '0' AND `kmtype_id` = $kmtype_id ORDER BY `daili` DESC");
            $km = $kmsql['km'];

            //判断充值价格是否和卡密一致（测试阶段可以进行注释）：
            $fee =$_GET['total_fee'];
            if ($fee<>$km_rmb) {
                echo'<p class="bg-danger">很抱歉，您支付的金额不足以购买此商品，请联系您的商家！<br>订单号：'.$buyerid.'</p>';
            }else{
                $myrow=$DB->get_row("select * from auth_kms where kind=1 and km='$km' limit 1");
                $addll = $myrow['values']*1024*1024*1024;//流量
                $duetime = time() + $myrow['value']*24*60*60;//时间

                /*echo "<script language='javascript'>alert('充值的用户是".$u."');</script>";
                echo "<script language='javascript'>alert('他的代理是".$dlid."');</script>";
                echo "<script language='javascript'>alert('卡类id是".$kmtype_id."；提出来的卡密是".$km."');</script>";*/
                //充值给用户：
                if ($km) {
                    if($res['endtime'] < time()){
                        $sql="update `openvpn` set `isent`='0',`irecv`='0',`maxll`='{$addll}',`endtime`='{$duetime}',`dlid`='{$myrow['daili']}',`i`='1' where `iuser`='{$u}'";
                        if($DB->query($sql)){
                            $DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
                            wlog('账号激活','用户'.$u.'使用激活码'.$km.'开通账号['.$date.'][支付宝订单号：'.$buyerid.']');

                            //充值的金额记录给代理：
                            $rmb=$DB->get_row("select * from auth_daili where id='$dlid' limit 1");
                            $dlrmb = round($rmb['income']+$km_rmb);
                            if($dlrmb){
                                $DB->query("update `auth_daili` set `income` ='$dlrmb' where id='$dlid' limit 1");
                                //echo "<script language='javascript'>alert('他的收入总计".$dlrmb."');</script>";
                            }

                            echo '<div class="alert alert-success">
                                                    <button type="button" class="close">
                                                        <span aria-hidden="true"><a href="/user/index.php?user='.$p.'&pass='.$u.'">×</a></span>
                                                        <span class="sr-only">Close</span>
                                                    </button>
                                                    <strong>订单支付完成：</strong><br>
                                                    帐号'.$u.'开通成功！
                                                </div>';

                        }else{
                            echo'<div class="alert alert-danger">
                                                    <button type="button" class="close">
                                                        <span aria-hidden="true"><a href="/user/index.php?user='.$p.'&pass='.$u.'">×</a></span>
                                                        <span class="sr-only">Close</span>
                                                    </button>
                                                    帐号'.$u.'开通失败！
                                                </div>';
                        }
                    }else{
                        $maxll = round($u_ll+$addll);
                        $sql="update `openvpn` set `maxll`='{$maxll}',`endtime`='{$duetime}',`i`='1' where `iuser`='{$u}'";
                        if($DB->query($sql)){
                            $DB->query("update `auth_kms` set `isuse` ='1',`user` ='$u',`usetime` ='$date' where `id`='{$myrow['id']}'");
                            wlog('账号充值','用户'.$u.'使用激活码'.$km.'续费账号['.$km_rmb.'][支付宝订单号：'.$buyerid.']');

                            //充值的金额记录给代理：
                            $rmb=$DB->get_row("select * from auth_daili where id='$dlid' limit 1");
                            $dlrmb = round($rmb['income']+$km_rmb);
                            if($dlrmb){
                                $DB->query("update `auth_daili` set `income` ='$dlrmb' where id='$dlid' limit 1");
                                //echo "<script language='javascript'>alert('他的收入总计".$dlrmb."');</script>";
                            }
                            echo '<div class="alert alert-success">
                                                    <button type="button" class="close">
                                                        <span aria-hidden="true"><a href="/user/index.php?user='.$p.'&pass='.$u.'">×</a></span>
                                                        <span class="sr-only">Close</span>
                                                    </button>
                                                    <strong>订单支付完成：</strong><br>
                                                    帐号'.$u.'续费成功！
                                                </div>';
                        }else{
                            echo'<div class="alert alert-danger">
                                                    <button type="button" class="close">
                                                        <span aria-hidden="true"><a href="/user/index.php?user='.$p.'&pass='.$u.'">×</a></span>
                                                        <span class="sr-only">Close</span>
                                                    </button>
                                                    帐号'.$u.'续费失败！
                                                </div>';
                        }
                    }
                }else{
                    echo'<div class="alert alert-danger">
                                            <button type="button" class="close">
                                                <span aria-hidden="true"><a href="/user/index.php?user='.$p.'&pass='.$u.'">×</a></span>
                                                <span class="sr-only">Close</span>
                                            </button>
                                            <strong>很抱歉，此套餐没有库存了，请联系您的商家！<br>
                                            订单号：'.$buyerid.'
                                        </div>';
                }
            }

    }else{//代理充值

            $value =$_GET['total_fee'];
            $now_rmb = $dl_rmb + $value;
            //echo "<script language='javascript'>alert('".$u."');</script>";
            $DB->query("UPDATE auth_daili SET rmb='{$now_rmb}' WHERE id='{$u}'");

            /*$DB->query("UPDATE auth_kms SET isuse=1,usetime='".date("Y-m-d H:i:s")."',user='{$u}' WHERE km='{$dl_km}' and kind=2");*/
            //$date = time();
            wlog('代理支付宝充值','代理'.$dl_u.'在线充值'.$value.'元['.$date.'][订单号：'.$buyerid.']');

            /*echo("<script>alert('充值的钱".$value."元');</script>");
            echo("<script>alert('原来的钱".$dl_rmb."元');</script>");
            echo("<script>alert('总和".$now_rmb."元');</script>");*/
            echo '<div class="alert alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="/daili">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>
                                        <strong>订单支付完成：</strong><br>
                                        成功充值'.$value.'元，余额剩余'.$now_rmb.'元！
                                    </div>';

    }




        
    //echo "验证成功<br />";

    //——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
    //验证失败
    //如要调试，请看alipay_notify.php页面的verifyReturn函数
    echo'<div class="alert alert-danger">
                                        <strong>提示：</strong>支付没有完成！
                                    </div>';
}
?>
                    
                </div>

            </div>

            <!-- Main Footer -->
            <?php include("../copy2.php");?>
        </div>
        
    </div>

<?php include("../user/js.php");?>

</body>
</html><?php 